import React, { useState, useEffect } from 'react';
import { StyleSheet, SafeAreaView, Text, View } from 'react-native';
import * as colors from '../assets/css/Colors';
import Icon, { Icons } from '../components/Icons';
import { bold, regular } from '../config/Constants';
import { useNavigation } from '@react-navigation/native';
import AppIntroSlider from 'react-native-app-intro-slider';
import LottieView from 'lottie-react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import LinearGradient from 'react-native-linear-gradient';
import { StatusBar } from '../components/StatusBar';



const Intro = () => {

  const navigation = useNavigation();
  const [showRealApp,setShowRealApp] = useState(false); 
  

  const slides = [
    {
      key: 1,
      title: "Your Doctor, Just a Tap Away",
      text: "Get professional medical advice securely from certified doctors. Enjoy instant consultations, follow-ups, and prescriptions—all from home.",
      image: require('.././assets/json/slider3.json'),
      colors: [ colors.theme_bg_three,colors.theme_bg], // Gradient colors,
    },
    {
      key: 2,
      title: "Hassle-Free Hospital Visits",
      text: "Book your appointment easily for convenient access to expert care. Choose your preferred time and connect with a specialist online.",
      image: require('.././assets/json/slider1.json'),
      colors: [ colors.theme_bg_three,colors.theme_bg], // Gradient colors
    },
    {
      key: 3,
      title: "Your Medicines, Your Way",
      text: "Simplify your health routine with quick pharmacy orders. Search medicines, upload prescriptions, and get fast delivery at your door.",
      image: require('.././assets/json/slider_3.json'),
      colors: [ colors.theme_bg_three,colors.theme_bg], // Gradient colors,
    },
    {
      key: 4,
      title: "Diagnostics Made Simple",
      text: "Schedule lab tests conveniently. Select from trusted labs, opt for home sample collection, and access reports digitally.",
      image: require('.././assets/json/slider_4.json'),
      colors: [ colors.theme_bg_three,colors.theme_bg], // Gradient colors,
    }
  ];

/*   useEffect(() => {
    if(global.existing == 1){
      setShowRealApp(true);
    }
  },[]); */

  const renderItem = ({item}: {item: Item}) => {
    return (
      <LinearGradient
      colors={item.colors}
      start={{ x: 0.5, y: 0.4 }} end={{ x: 1, y: 1 }}
      style={styles.slide}>
        <Text style={styles.title}>{item.title}</Text>
        <View style={{ height: '50%', width: '70%'}}>
          <LottieView style={{flex:1}}source={item.image} autoPlay loop />
        </View>
        <Text style={styles.text}>{item.text}</Text>
        </LinearGradient>
    );
  };

  const onDone = async() => {
    setShowRealApp(true);
    try{
        await AsyncStorage.setItem('existing', parseInt(1).toString());
        global.existing = await parseInt(1).toString();
console.log(global.existing+'1')
        setTimeout(() => {
          navigation.navigate('Home');
        }, 200);
      }catch (e) {
        alert(e);
    } 
  }
  const onSkip = () => {
    navigation.navigate('Home');
  };

  const renderNextButton = () => {
    return (
      <View style={styles.buttonCircle}>
        <Icon type={Icons.Ionicons} name="chevron-forward" color={colors.theme_fg_three} style={{ fontSize:25 }} />
      </View>
    );
  };

  const renderPrevButton = () => {
    return (
      <View style={styles.buttonCircle}>
        <Icon type={Icons.Ionicons} name="chevron-back" color={colors.theme_fg_three} style={{ fontSize:25 }} />
      </View>
    );
  };
  
  const renderDoneButton = () => {
    return (
      <View style={styles.buttonCircle}>
        <Icon type={Icons.Ionicons} name="home" color={colors.theme_fg_three} style={{ fontSize:25 }} />
      </View>
    );
  };


  const keyExtractor = (item: Item) => item.title;
  return (
    <SafeAreaView style={styles.container}>
      <StatusBar/>
        <View style={{flex: 1}}>
          <AppIntroSlider
            keyExtractor={keyExtractor}
            renderItem={renderItem}
            onDone={onDone}
            onSkip={onSkip}
            showSkipButton
            showPrevButton
            activeDotStyle={{ backgroundColor:colors.theme_bg }}
            renderDoneButton={renderDoneButton}
            renderNextButton={renderNextButton}
            renderPrevButton={renderPrevButton}
            data={slides}
          />
        </View>
    </SafeAreaView>
  );

}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  textFieldcontainer: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 10,
    marginTop: 5,
    marginBottom: 5,
    height: 45
  },
  textFieldIcon: {
    padding:5
  },
  textField: {
    flex: 1,
    padding: 12,
    borderRadius: 10,
    height: 45,
    backgroundColor:colors.theme_bg_three,
    fontSize:14,
    color:colors.grey
  },
  button: {
    padding:10,
    borderRadius: 10,
    height:40,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor:colors.theme_bg,
    width:'100%',
    height:45
  },


  slide: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingBottom: 96, 
    width: '100%',
  },
  image: {
    width: 320,
    height: 320,
    marginTop: 32,
  },
  title: {
    fontSize: 25,
    color:colors.theme_fg_two,
    fontFamily:bold,
    textAlign: 'center',
  },
  text:{
    fontSize:19,
    fontFamily:regular,
    color:colors.theme_bg_three,
    marginTop:20,
    alignItems: 'center',
    justifyContent: 'center',
    textAlign: 'justify',
    padding:10,
  },
  buttonCircle: {
    width: 40,
    height: 40,
    backgroundColor: colors.theme_bg,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
});

export default Intro;